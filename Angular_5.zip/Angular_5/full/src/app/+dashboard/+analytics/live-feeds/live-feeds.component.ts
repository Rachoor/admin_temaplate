import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'live-feeds-widget',
  templateUrl: './live-feeds.component.html',
  styles: []
})
export class LiveFeedsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
