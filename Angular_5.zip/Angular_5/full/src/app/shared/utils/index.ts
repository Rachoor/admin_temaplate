/**
 * Created by griga on 6/20/16.
 */


export {MomentPipe} from './moment.pipe'
