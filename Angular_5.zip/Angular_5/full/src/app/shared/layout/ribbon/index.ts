export { RibbonComponent } from './ribbon.component';
