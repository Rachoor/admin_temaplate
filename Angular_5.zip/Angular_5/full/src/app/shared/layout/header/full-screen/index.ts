export { FullScreenComponent } from './full-screen.component';
