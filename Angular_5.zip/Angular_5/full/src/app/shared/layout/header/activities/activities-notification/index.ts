export { ActivitiesNotificationComponent } from './activities-notification.component';
