import { Component, OnInit } from '@angular/core';
import {fadeInTop} from "../shared/animations/router.animations";

@Component({
  selector: 'sa-calendar',
  templateUrl: './calendar.component.html',
})

export class CalendarComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
