import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'image-editor-animations-panel',
  templateUrl: './animations-panel.component.html',
  styles: []
})
export class AnimationsPanelComponent implements OnInit {

  public storeId = 'animationsPanel';

  constructor() { }

  ngOnInit() {
  }

}
