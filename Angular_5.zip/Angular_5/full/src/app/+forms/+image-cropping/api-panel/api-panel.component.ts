import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'image-editor-api-panel',
  templateUrl: './api-panel.component.html',
})
export class ApiPanelComponent implements OnInit {

  public storeId = 'apiPanel';

  constructor() {}

  ngOnInit() {
  }

}
