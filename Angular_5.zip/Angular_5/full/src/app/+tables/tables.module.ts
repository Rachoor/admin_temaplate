import {NgModule} from '@angular/core';
import {routing} from './tables.routing';


@NgModule({
  declarations: [],
  imports: [    
    routing
  ],
})
export class TablesModule {}
